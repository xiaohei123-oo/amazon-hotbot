from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


TRACKING_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "ref", "tag"}

TAG_KEYWORDS: dict[str, list[str]] = {
    "policy": ["policy", "compliance", "regulation", "requirement", "restricted", "safety", "合规", "政策", "监管"],
    "fba": ["fba", "fulfillment", "inventory", "warehouse", "returns", "prep", "label", "配送", "库存", "退货"],
    "ads": ["advertising", "ads", "sponsored", "campaign", "attribution", "广告", "投放"],
    "api": ["sp-api", "api", "developer", "release notes", "changelog", "listings items", "接口", "开发者"],
    "account": ["account health", "suspension", "verification", "seller performance", "账号", "封号", "绩效"],
    "listing": ["listing", "attribute", "enumeration", "product type", "variation", "asin", "类目", "变体"],
    "prime": ["prime day", "deal", "coupon", "promotion", "旺季", "促销"],
    "brand": ["brand registry", "transparency", "vine", "a+ content", "品牌"],
}


def clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", value)).strip()


def normalize_url(url: str) -> str:
    parts = urlsplit(url.strip())
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True) if k.lower() not in TRACKING_PARAMS]
    path = parts.path.rstrip("/") or "/"
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, urlencode(query), ""))


def detect_language(text: str) -> str:
    cjk = len(re.findall(r"[\u4e00-\u9fff]", text))
    letters = len(re.findall(r"[A-Za-z]", text))
    return "zh" if cjk > letters * 0.25 else "en"


def tokenize(text: str) -> set[str]:
    words = re.findall(r"[a-zA-Z0-9][a-zA-Z0-9\-]{2,}|[\u4e00-\u9fff]{2,}", text.lower())
    stop = {"amazon", "the", "and", "for", "with", "from", "this", "that", "your", "seller", "sellers"}
    return {word for word in words if word not in stop}


def tag_text(text: str, default_category: str | None = None) -> list[str]:
    low = text.lower()
    tags = [tag for tag, keywords in TAG_KEYWORDS.items() if any(keyword in low for keyword in keywords)]
    if default_category and default_category not in tags:
        tags.append(default_category)
    return tags or ["marketplace"]


def canonical_title(title: str) -> str:
    return clean_text(re.sub(r"[^a-zA-Z0-9\u4e00-\u9fff ]+", " ", title.lower()))
