from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx

from .config import Settings
from .db import Database, row_to_dict


ACTIONABLE_TAGS = {"policy", "api", "account", "fba", "listing", "ads", "prime", "brand", "seller"}
GENERIC_TITLES = {
    "conditions of use",
    "policies and agreements",
    "find products to sell",
    "seller central",
    "developer hub",
    "release notes",
    "api reference",
    "code samples",
    "jump to content",
    "inventory management",
    "documentation",
    "español - us",
    "english - us",
    "sustainability",
    "artificial intelligence",
    "entertainment",
    "how to sell online get an overview for running an ecommerce business",
}


def is_actionable_cluster(cluster: dict) -> bool:
    title = str(cluster.get("title", "")).strip().lower()
    if title in GENERIC_TITLES:
        return False
    return bool(ACTIONABLE_TAGS & set(cluster.get("tags", [])))


def safe_zoneinfo(timezone_name: str):
    try:
        return ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError:
        if timezone_name == "Asia/Shanghai":
            return timezone(timedelta(hours=8), name="Asia/Shanghai")
        return timezone.utc


def build_feishu_payload(clusters: list[dict], timezone_name: str = "Asia/Shanghai") -> dict:
    today = datetime.now(safe_zoneinfo(timezone_name)).strftime("%Y-%m-%d")
    lines = [f"Amazon 热点日报 {today}", ""]
    for index, cluster in enumerate(clusters[:10], start=1):
        tags = "/".join(cluster.get("tags", [])[:3])
        lines.append(f"{index}. [{cluster['score']}] {cluster['title']}")
        lines.append(f"   标签：{tags or 'marketplace'}｜可信度：{cluster['confidence']}｜来源：{cluster['source_count']}")
        if cluster.get("summary"):
            lines.append(f"   {cluster['summary'][:120]}")
        if cluster.get("source_url"):
            lines.append(f"   阅读原文：{cluster['source_url']}")
        lines.append(f"   站内详情：/clusters/{cluster['id']}")
    if not clusters:
        lines.append("今天没有抓到新的高置信 Amazon 热点。")
    return {"msg_type": "text", "content": {"text": "\n".join(lines)}}


async def send_feishu(settings: Settings, payload: dict, dry_run: bool | None = None) -> dict:
    effective_dry_run = settings.dry_run if dry_run is None else dry_run
    if effective_dry_run or not settings.feishu_webhook_url:
        return {"dry_run": True, "payload": payload}
    async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
        response = await client.post(settings.feishu_webhook_url, json=payload)
        response.raise_for_status()
        return response.json()


async def notify_daily(db: Database, settings: Settings, dry_run: bool | None = None) -> dict:
    clusters = [row_to_dict(row) for row in db.get_clusters(limit=100)]
    clusters = [cluster for cluster in clusters if is_actionable_cluster(cluster)][:10]
    for cluster in clusters:
        _, items = db.get_cluster(int(cluster["id"]))
        if items:
            cluster["source_url"] = items[0]["url"]
    payload = build_feishu_payload(clusters, settings.timezone)
    result = await send_feishu(settings, payload, dry_run)
    db.add_run("notify", "ok", {"count": len(clusters), "dry_run": result.get("dry_run", False)})
    return result


def payload_json(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2)
