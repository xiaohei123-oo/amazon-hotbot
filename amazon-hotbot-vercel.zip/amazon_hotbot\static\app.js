var state = { clusters: [], view: "selected" };

var t = {
  selected: "\u6700\u65b0\u7cbe\u9009",
  all: "\u5168\u90e8 Amazon \u52a8\u6001",
  daily: "Amazon \u65e5\u62a5",
  topics: "\u4e3b\u9898",
  today: "\u4eca\u5929",
  dailyFocus: "\u4eca\u65e5\u770b\u70b9",
  noData: "\u6682\u65e0\u6570\u636e",
  noDataHint: "\u8fd0\u884c\u6293\u53d6\u4efb\u52a1\u540e\u4f1a\u5728\u8fd9\u91cc\u51fa\u73b0 Amazon \u70ed\u70b9\u3002",
  latestRun: "\u6700\u8fd1\u8fd0\u884c",
  notRun: "\u5c1a\u672a\u8fd0\u884c\u6293\u53d6\u4efb\u52a1",
  loadFailed: "\u52a0\u8f7d\u5931\u8d25",
  items: "\u6761\u52a8\u6001",
  sources: "\u4fe1\u6e90",
  official: "\u5b98\u65b9",
  unofficial: "\u975e\u5b98\u65b9",
  detail: "\u4e8b\u4ef6\u8be6\u60c5",
  selectedCount: "\u7cbe\u9009",
  riskCount: "\u9ad8\u4f18\u5148",
  officialCount: "\u5b98\u65b9\u6e90"
};

function fmtDate(value) {
  return new Date(value).toLocaleDateString("zh-CN", { month: "long", day: "numeric", weekday: "short" });
}

function fmtTime(value) {
  return new Date(value).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false });
}

function html(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function getJson(url, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState !== 4) return;
    if (xhr.status >= 200 && xhr.status < 300) {
      callback(null, JSON.parse(xhr.responseText));
    } else {
      callback(new Error(xhr.status + " " + xhr.statusText));
    }
  };
  xhr.onerror = function () {
    callback(new Error("network error"));
  };
  xhr.send();
}

function postJson(url, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", url, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState !== 4) return;
    if (xhr.status >= 200 && xhr.status < 300) {
      callback(null, JSON.parse(xhr.responseText));
    } else {
      callback(new Error(xhr.status + " " + xhr.statusText));
    }
  };
  xhr.onerror = function () {
    callback(new Error("network error"));
  };
  xhr.send();
}

function setView(view) {
  state.view = view;
  var buttons = document.querySelectorAll(".rail-link[data-view]");
  for (var i = 0; i < buttons.length; i += 1) {
    buttons[i].classList.toggle("active", buttons[i].getAttribute("data-view") === view);
  }
  document.getElementById("pageTitle").textContent = t[view] || t.selected;
  load();
}

function renderDigestStats(daily) {
  var top = daily.top || [];
  var risk = daily.high_risk || [];
  var officialCount = 0;
  for (var i = 0; i < top.length; i += 1) {
    if (Number(top[i].official_source_count || 0) > 0) officialCount += 1;
  }
  document.getElementById("digestStats").innerHTML =
    '<div class="stat"><strong>' + top.length + "</strong><span>" + t.selectedCount + "</span></div>" +
    '<div class="stat"><strong>' + risk.length + "</strong><span>" + t.riskCount + "</span></div>" +
    '<div class="stat"><strong>' + officialCount + "</strong><span>" + t.officialCount + "</span></div>";
}

function groupByDay(clusters) {
  var acc = {};
  for (var i = 0; i < clusters.length; i += 1) {
    var key = fmtDate(clusters[i].last_seen_at);
    if (!acc[key]) acc[key] = [];
    acc[key].push(clusters[i]);
  }
  return acc;
}

function renderStream() {
  var list = document.getElementById("clusterList");
  var clusters = state.view === "selected" ? state.clusters.slice(0, 30) : state.clusters;
  document.getElementById("feedTitle").textContent = state.view === "daily" ? t.dailyFocus : t.today;
  document.getElementById("feedMeta").textContent = clusters.length + " " + t.items;

  if (!clusters.length) {
    list.innerHTML = '<article class="news-item"><div></div><div><h3>' + t.noData + '</h3><p class="summary">' + t.noDataHint + "</p></div></article>";
    return;
  }

  var grouped = groupByDay(clusters);
  var out = "";
  for (var day in grouped) {
    if (!Object.prototype.hasOwnProperty.call(grouped, day)) continue;
    out += '<div class="day-title">' + html(day) + "</div>";
    for (var i = 0; i < grouped[day].length; i += 1) {
      out += renderItem(grouped[day][i]);
    }
  }
  list.innerHTML = out;

  var items = list.querySelectorAll(".news-item");
  for (var j = 0; j < items.length; j += 1) {
    items[j].addEventListener("click", function () {
      showDetail(this.getAttribute("data-id"));
    });
  }
}

function renderItem(cluster) {
  var tags = (cluster.tags || []).slice(0, 3);
  var score = Number(cluster.score || 0);
  var tagHtml = "";
  for (var i = 0; i < tags.length; i += 1) {
    tagHtml += '<span class="tag">' + html(tags[i]) + "</span>";
  }
  return (
    '<article class="news-item" data-id="' + html(cluster.id) + '">' +
    '<time class="news-time">' + fmtTime(cluster.last_seen_at) + "</time>" +
    "<div>" +
    "<h3>" + html(cluster.title) + "</h3>" +
    '<p class="summary">' + html(cluster.summary || "") + "</p>" +
    '<div class="meta">' + tagHtml +
    '<span class="tag">' + html(cluster.confidence) + "</span>" +
    '<span class="tag">' + cluster.source_count + " " + t.sources + "</span>" +
    "</div></div>" +
    '<div class="score ' + (score >= 80 ? "hot" : "") + '">' + score.toFixed(0) + "</div>" +
    "</article>"
  );
}

function showDetail(id) {
  getJson("/api/clusters/" + encodeURIComponent(id), function (err, detail) {
    if (err) return;
    var breakdown = detail.score_breakdown || {};
    var tagHtml = "";
    var tags = detail.tags || [];
    for (var i = 0; i < tags.length; i += 1) {
      tagHtml += '<span class="tag">' + html(tags[i]) + "</span>";
    }
    var breakdownHtml = "";
    for (var key in breakdown) {
      if (!Object.prototype.hasOwnProperty.call(breakdown, key)) continue;
      breakdownHtml += "<div><strong>" + html(key) + "</strong><br>" + html(breakdown[key]) + "</div>";
    }
    var evidenceHtml = "";
    var rows = detail.items || [];
    for (var j = 0; j < rows.length; j += 1) {
      evidenceHtml +=
        "<li>" +
        '<a href="' + html(rows[j].url) + '" target="_blank" rel="noreferrer">' + html(rows[j].title) + "</a>" +
        "<p>" + html(rows[j].source_name) + " &#183; " + fmtTime(rows[j].published_at) + " &#183; " + (rows[j].official ? t.official : t.unofficial) + "</p>" +
        "</li>";
    }
    document.getElementById("detail").innerHTML =
      '<p class="digest-kicker">' + t.detail + "</p>" +
      "<h2>" + html(detail.title) + "</h2>" +
      "<p>" + html(detail.summary || "") + "</p>" +
      '<div class="meta">' + tagHtml + '<span class="tag">score ' + html(detail.score) + "</span>" +
      '<span class="tag">' + html(detail.confidence) + "</span></div>" +
      '<div class="breakdown">' + breakdownHtml + "</div>" +
      '<ul class="evidence">' + evidenceHtml + "</ul>";
    history.replaceState(null, "", "/clusters/" + id);
  });
}

function load() {
  var tag = document.getElementById("tagFilter").value;
  var limit = state.view === "all" ? 200 : 100;
  var clusterUrl = "/api/clusters?limit=" + limit + (tag ? "&tag=" + encodeURIComponent(tag) : "");
  var remaining = 3;
  var data = {};

  function done(name, err, value) {
    if (err) {
      document.getElementById("status").textContent = t.loadFailed + ": " + err.message;
      return;
    }
    data[name] = value;
    remaining -= 1;
    if (remaining === 0) renderLoaded(data.health, data.daily, data.clusters);
  }

  getJson("/api/health", function (err, value) { done("health", err, value); });
  getJson("/api/daily/latest", function (err, value) { done("daily", err, value); });
  getJson(clusterUrl, function (err, value) { done("clusters", err, value); });
}

function renderLoaded(health, daily, clusters) {
  var latest = health.latest_run;
  document.getElementById("todayLabel").textContent = "AMZ HOT " + fmtDate(new Date());
  document.getElementById("status").textContent = latest
    ? t.latestRun + ": " + latest.kind + " \u00b7 " + latest.status + " \u00b7 " + new Date(latest.created_at).toLocaleString("zh-CN", { hour12: false })
    : t.notRun;

  renderDigestStats(daily);
  state.clusters = state.view === "daily" ? (daily.top || []) : clusters;
  renderStream();

  var match = location.pathname.match(/\/clusters\/(\d+)/);
  if (match) showDetail(match[1]);
}

function bind() {
  var viewButtons = document.querySelectorAll(".rail-link[data-view]");
  for (var i = 0; i < viewButtons.length; i += 1) {
    viewButtons[i].addEventListener("click", function () {
      setView(this.getAttribute("data-view"));
    });
  }

  var topicButtons = document.querySelectorAll(".topic");
  for (var j = 0; j < topicButtons.length; j += 1) {
    topicButtons[j].addEventListener("click", function () {
      for (var k = 0; k < topicButtons.length; k += 1) topicButtons[k].classList.remove("active");
      this.classList.add("active");
      document.getElementById("tagFilter").value = this.getAttribute("data-tag");
      load();
    });
  }

  document.getElementById("refreshBtn").addEventListener("click", load);
  document.getElementById("tagFilter").addEventListener("change", load);
  document.getElementById("dryRunBtn").addEventListener("click", function () {
    postJson("/api/run/notify?dry_run=true", function (err, result) {
      if (err) {
        alert(err.message);
        return;
      }
      alert(JSON.stringify(result, null, 2));
    });
  });
}

bind();
load();
