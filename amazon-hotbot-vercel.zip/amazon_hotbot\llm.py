from __future__ import annotations

import json

import httpx

from .config import Settings


async def summarize_with_llm(settings: Settings, title: str, evidence: list[dict[str, str]]) -> str | None:
    if not settings.openai_api_key:
        return None
    evidence_text = "\n".join(f"- {item['source']}: {item['title']} {item['url']}" for item in evidence[:5])
    prompt = (
        "你是跨境电商 Amazon 政策/热点分析助手。基于证据源写一句中文摘要，"
        "不要夸大单一弱源，不要编造。输出不超过80字。\n"
        f"事件标题：{title}\n证据：\n{evidence_text}"
    )
    payload = {
        "model": settings.openai_model,
        "messages": [
            {"role": "system", "content": "You write concise, evidence-grounded Chinese ecommerce intelligence."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.2,
    }
    headers = {"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
        response = await client.post(f"{settings.openai_base_url.rstrip('/')}/chat/completions", headers=headers, content=json.dumps(payload))
        response.raise_for_status()
        data = response.json()
    return data["choices"][0]["message"]["content"].strip()
