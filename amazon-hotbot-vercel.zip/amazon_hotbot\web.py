from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from .config import get_settings
from .db import Database, row_to_dict
from .notify import notify_daily
from .notify import is_actionable_cluster
from .pipeline import fetch_step, process_step, run_once

try:
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from apscheduler.triggers.cron import CronTrigger
except Exception:  # pragma: no cover - only used when dependency is missing
    AsyncIOScheduler = None
    CronTrigger = None


settings = get_settings()
db = Database(settings.database_url)
static_dir = Path(__file__).parent / "static"

APP_JS = r'''
var state={clusters:[],daily:{top:[],high_risk:[]},health:null,view:"selected",loading:false,lang:localStorage.getItem("amz_hot_lang")||"zh"};
var I18N={
zh:{selected:"\u6700\u65b0\u7cbe\u9009",all:"\u5168\u90e8 Amazon \u52a8\u6001",daily:"Amazon \u65e5\u62a5",topics:"\u4e3b\u9898",today:"\u4eca\u5929",allToday:"\u5168\u90e8\u52a8\u6001",dailyFocus:"\u65e5\u62a5\u6458\u8981",topicBoard:"\u4e3b\u9898\u770b\u677f",items:"\u6761\u52a8\u6001",sources:"\u4fe1\u6e90",official:"\u5b98\u65b9",unofficial:"\u975e\u5b98\u65b9",detail:"\u4e8b\u4ef6\u8be6\u60c5",latestRun:"\u6700\u8fd1\u8fd0\u884c",notRun:"\u5c1a\u672a\u8fd0\u884c\u6293\u53d6\u4efb\u52a1",loadFailed:"\u52a0\u8f7d\u5931\u8d25",loading:"\u52a0\u8f7d\u4e2d...",noData:"\u6682\u65e0\u6570\u636e",noDataHint:"\u8fd0\u884c\u6293\u53d6\u4efb\u52a1\u540e\u4f1a\u5728\u8fd9\u91cc\u51fa\u73b0 Amazon \u70ed\u70b9\u3002",selectedCount:"\u7cbe\u9009",riskCount:"\u9ad8\u4f18\u5148",officialCount:"\u5b98\u65b9\u6e90",refresh:"\u5237\u65b0",refreshing:"\u5237\u65b0\u4e2d",content:"\u5185\u5bb9",integration:"\u63a5\u5165",allFilter:"\u5168\u90e8",agentDryRun:"Agent / \u98de\u4e66 dry-run",sourceStatus:"\u6309\u4e1a\u52a1\u7ef4\u5ea6\u805a\u5408",noTopic:"\u6682\u65e0\u76f8\u5173\u52a8\u6001",allDesc:"\u8fd9\u91cc\u4fdd\u7559\u5168\u90e8\u6293\u53d6\u540e\u7684\u805a\u7c7b\u52a8\u6001\uff0c\u9002\u5408\u6392\u67e5\u4fe1\u6e90\u8986\u76d6\u548c\u957f\u5c3e\u4e8b\u4ef6\u3002",topicsDesc:"\u70b9\u51fb\u4e3b\u9898\u5361\u7247\u4f1a\u5207\u5230\u5bf9\u5e94\u5206\u7c7b\u7684\u5168\u90e8\u52a8\u6001\u3002\u8fd9\u4e2a\u89c6\u56fe\u7528\u6765\u770b\u653f\u7b56\u3001FBA\u3001API\u3001\u5e7f\u544a\u7b49\u7ef4\u5ea6\u7684\u70ed\u5ea6\u5206\u5e03\u3002",dailyDesc:"\u4eca\u65e5\u770b\u70b9\u4f1a\u81ea\u52a8\u805a\u5408\u653f\u7b56\u3001FBA\u3001\u5e7f\u544a\u548c SP-API \u53d8\u66f4\u3002",highPriority:"\u9ad8\u4f18\u5148\u63d0\u9192",noRisk:"\u6682\u65e0\u9ad8\u4f18\u5148\u98ce\u9669\u9879\u3002",dailyPush:"\u98de\u4e66\u6bcf\u65e5 09:00 \u63a8\u9001 Top 10",refreshStatus:"\u6b63\u5728\u6293\u53d6\u516c\u5f00\u4fe1\u6e90\u5e76\u91cd\u5efa\u70ed\u70b9...",readOriginal:"\u9605\u8bfb\u539f\u6587",langButton:"\u4e2d\u6587",subtitle:"Amazon daily intelligence"},
en:{selected:"Latest Picks",all:"All Amazon Updates",daily:"Amazon Daily",topics:"Topics",today:"Today",allToday:"All Updates",dailyFocus:"Daily Brief",topicBoard:"Topic Board",items:"updates",sources:"sources",official:"Official",unofficial:"Unofficial",detail:"Event Detail",latestRun:"Latest run",notRun:"No fetch job has run yet",loadFailed:"Load failed",loading:"Loading...",noData:"No data yet",noDataHint:"Run a fetch job and Amazon signals will appear here.",selectedCount:"Picks",riskCount:"High priority",officialCount:"Official sources",refresh:"Refresh",refreshing:"Refreshing",content:"Content",integration:"Integration",allFilter:"All",agentDryRun:"Agent / Feishu dry-run",sourceStatus:"Grouped by business topic",noTopic:"No related updates yet",allDesc:"All clustered updates are kept here for checking source coverage and long-tail events.",topicsDesc:"Click a topic card to switch to the matching update stream. This view shows heat across policy, FBA, API, ads, and other operating areas.",dailyDesc:"Today's brief automatically aggregates policy, FBA, ads, and SP-API changes.",highPriority:"High Priority",noRisk:"No high-priority risk items right now.",dailyPush:"Feishu sends Top 10 daily at 09:00",refreshStatus:"Fetching public sources and rebuilding hot clusters...",readOriginal:"Read original",langButton:"English",subtitle:"Amazon daily intelligence"}};
var TOPIC_NAMES={zh:{policy:"\u653f\u7b56",api:"API",fba:"FBA",ads:"\u5e7f\u544a",account:"\u8d26\u53f7",listing:"Listing",prime:"Prime",brand:"\u54c1\u724c",seller:"Seller",marketplace:"Marketplace"},en:{policy:"Policy",api:"API",fba:"FBA",ads:"Ads",account:"Account",listing:"Listing",prime:"Prime",brand:"Brand",seller:"Seller",marketplace:"Marketplace"}};
var t=I18N[state.lang],topicNames=TOPIC_NAMES[state.lang];
function fmtDate(v){return new Date(v).toLocaleDateString("zh-CN",{month:"long",day:"numeric",weekday:"short"});}
function fmtTime(v){return new Date(v).toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",hour12:false});}
function html(v){return String(v==null?"":v).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function getJson(url,cb){var x=new XMLHttpRequest();x.open("GET",url,true);x.onreadystatechange=function(){if(x.readyState!==4)return;if(x.status>=200&&x.status<300)cb(null,JSON.parse(x.responseText));else cb(new Error(x.status+" "+x.statusText));};x.onerror=function(){cb(new Error("network error"));};x.send();}
function postJson(url,cb){var x=new XMLHttpRequest();x.open("POST",url,true);x.onreadystatechange=function(){if(x.readyState!==4)return;if(x.status>=200&&x.status<300)cb(null,JSON.parse(x.responseText));else cb(new Error(x.status+" "+x.statusText));};x.onerror=function(){cb(new Error("network error"));};x.send();}
function setText(sel,text){var el=document.querySelector(sel);if(el)el.textContent=text;}
function updateChoiceLabels(){var labels={policy:topicNames.policy,api:topicNames.api,fba:topicNames.fba,ads:topicNames.ads,account:topicNames.account,listing:topicNames.listing,prime:topicNames.prime,brand:topicNames.brand};var opts=document.querySelectorAll("#tagFilter option");for(var i=0;i<opts.length;i++){var v=opts[i].value;opts[i].textContent=v?labels[v]||v:t.allFilter;}var tabs=document.querySelectorAll(".topic");for(var j=0;j<tabs.length;j++){var tag=tabs[j].getAttribute("data-tag");tabs[j].textContent=tag?topicNames[tag]||tag:t.allFilter;}}
function applyLanguage(){t=I18N[state.lang];topicNames=TOPIC_NAMES[state.lang];document.documentElement.lang=state.lang==="zh"?"zh-CN":"en";setText(".logo-sub",t.subtitle);var sections=document.querySelectorAll(".rail-section p");if(sections[0])sections[0].textContent=t.content;if(sections[1])sections[1].textContent=t.integration;var nav={selected:t.selected,all:t.all,daily:t.daily,topics:t.topics};var links=document.querySelectorAll(".rail-link[data-view]");for(var i=0;i<links.length;i++){links[i].textContent=nav[links[i].getAttribute("data-view")];}setText("#dryRunBtn",t.agentDryRun);setText("#langToggle",t.langButton);setLoading(state.loading);updateChoiceLabels();document.getElementById("pageTitle").textContent=t[state.view]||t.selected;}
function toggleLang(){state.lang=state.lang==="zh"?"en":"zh";localStorage.setItem("amz_hot_lang",state.lang);applyLanguage();renderCurrent();var m=location.pathname.match(/\/clusters\/(\d+)/);if(m)showDetail(m[1]);}
function setView(view){state.view=view;var bs=document.querySelectorAll(".rail-link[data-view]");for(var i=0;i<bs.length;i++)bs[i].classList.toggle("active",bs[i].getAttribute("data-view")===view);document.getElementById("pageTitle").textContent=t[view]||t.selected;renderCurrent();}
function setLoading(on){state.loading=on;var btn=document.getElementById("refreshBtn");btn.textContent=on?t.refreshing:t.refresh;btn.classList.toggle("is-loading",on);}
function setTopicActive(tag){var ts=document.querySelectorAll(".topic");for(var i=0;i<ts.length;i++)ts[i].classList.toggle("active",ts[i].getAttribute("data-tag")===tag);}
function renderDigestStats(daily){var top=daily.top||[],risk=daily.high_risk||[],official=0;for(var i=0;i<top.length;i++)if(Number(top[i].official_source_count||0)>0)official++;var el=document.getElementById("digestStats");if(el)el.innerHTML='<div class="stat"><strong>'+top.length+"</strong><span>"+t.selectedCount+'</span></div><div class="stat"><strong>'+risk.length+"</strong><span>"+t.riskCount+'</span></div><div class="stat"><strong>'+official+"</strong><span>"+t.officialCount+"</span></div>";}
function sortByTime(cs){return (cs||[]).slice().sort(function(a,b){return new Date(b.last_seen_at||0)-new Date(a.last_seen_at||0);});}
function groupByDay(cs){var out=[];for(var i=0;i<cs.length;i++){var k=fmtDate(cs[i].last_seen_at),last=out[out.length-1];if(!last||last.day!==k){last={day:k,items:[]};out.push(last);}last.items.push(cs[i]);}return out;}
function tagHtml(tags){var out="",a=(tags||[]).slice(0,3);for(var i=0;i<a.length;i++)out+='<span class="tag">'+html(topicNames[a[i]]||a[i])+"</span>";return out;}
function renderItem(c,compact){var score=Number(c.score||0),full=new Date(c.last_seen_at).toLocaleString("zh-CN",{hour12:false});return '<article class="news-item '+(compact?"compact":"")+'" data-id="'+html(c.id)+'"><time class="news-time" datetime="'+html(c.last_seen_at)+'" title="'+html(full)+'">'+fmtTime(c.last_seen_at)+"</time><div><h3><a href=\"/clusters/"+html(c.id)+"\">"+html(c.title)+'</a></h3><p class="summary">'+html(c.summary||c.title)+'</p><div class="meta">'+tagHtml(c.tags)+'<span class="tag">'+html(c.confidence)+'</span><span class="tag">'+c.source_count+" "+t.sources+'</span></div></div><div class="score '+(score>=80?"hot":"")+'">'+score.toFixed(0)+"</div></article>";}
function bindNewsClicks(){var items=document.querySelectorAll(".news-item");for(var i=0;i<items.length;i++)items[i].addEventListener("click",function(){showDetail(this.getAttribute("data-id"));});}
function renderStream(cs,title,compact){var rows=sortByTime(cs),list=document.getElementById("clusterList");document.getElementById("feedTitle").textContent=title;document.getElementById("feedMeta").textContent=rows.length+" "+t.items;if(!rows.length){list.innerHTML='<article class="news-item"><div></div><div><h3>'+t.noData+'</h3><p class="summary">'+t.noDataHint+"</p></div></article>";return;}var g=groupByDay(rows),out="";for(var x=0;x<g.length;x++){out+='<div class="day-title"><span>'+html(g[x].day)+'</span><em>'+g[x].items.length+" "+t.items+"</em></div>";for(var i=0;i<g[x].items.length;i++)out+=renderItem(g[x].items[i],compact);}list.innerHTML=out;bindNewsClicks();}
function renderSelected(){var tag=document.getElementById("tagFilter").value,rows=tag?state.clusters.slice(0,30):(state.daily.top||[]).slice(0,10);document.querySelector(".content-grid").className="content-grid view-selected";renderStream(rows,t.today,false);renderDefaultDigest();}
function renderAll(){document.querySelector(".content-grid").className="content-grid view-all";renderStream(state.clusters,t.allToday,true);document.getElementById("detail").innerHTML='<p class="digest-kicker">ALL FEED</p><h2>'+t.all+'</h2><p>'+t.allDesc+'</p>'+statsHtml(state.clusters);}
function renderDaily(){var top=state.daily.top||[],risk=state.daily.high_risk||[];document.querySelector(".content-grid").className="content-grid view-daily";document.getElementById("feedTitle").textContent=t.dailyFocus;document.getElementById("feedMeta").textContent=top.length+" "+t.items;var out='<section class="daily-hero"><p>AMZ HOT DAILY</p><h2>'+fmtDate(new Date())+" "+t.daily+'</h2><span>'+t.dailyPush+'</span></section>';for(var i=0;i<top.length;i++)out+='<article class="daily-row" data-id="'+html(top[i].id)+'"><strong>'+(i+1)+'</strong><div><h3><a href=\"/clusters/'+html(top[i].id)+'\">'+html(top[i].title)+'</a></h3><p>'+html(top[i].summary||top[i].title)+'</p><div class="meta">'+tagHtml(top[i].tags)+'</div></div><div class="score '+(Number(top[i].score)>=80?"hot":"")+'">'+Number(top[i].score||0).toFixed(0)+'</div></article>';document.getElementById("clusterList").innerHTML=out;document.getElementById("detail").innerHTML='<p class="digest-kicker">HIGH PRIORITY</p><h2>'+t.highPriority+'</h2>'+riskList(risk)+statsHtml(top);bindDailyClicks();}
function renderTopics(){document.querySelector(".content-grid").className="content-grid view-topics";document.getElementById("feedTitle").textContent=t.topicBoard;document.getElementById("feedMeta").textContent=t.sourceStatus;var counts={},topBy={},all=state.clusters.concat(state.daily.top||[]);for(var i=0;i<all.length;i++){var tags=all[i].tags||[];for(var j=0;j<tags.length;j++){var k=tags[j];counts[k]=(counts[k]||0)+1;if(!topBy[k]||Number(all[i].score)>Number(topBy[k].score))topBy[k]=all[i];}}var order=["policy","api","fba","ads","account","listing","prime","brand","seller","marketplace"],out='<div class="topic-board">';for(var x=0;x<order.length;x++){var tag=order[x],c=counts[tag]||0,lead=topBy[tag];out+='<button class="topic-card" data-topic="'+tag+'" type="button"><span>'+html(topicNames[tag]||tag)+'</span><strong>'+c+'</strong><p>'+html(lead?lead.title:t.noTopic)+'</p></button>';}out+="</div>";document.getElementById("clusterList").innerHTML=out;document.getElementById("detail").innerHTML='<p class="digest-kicker">TOPICS</p><h2>'+t.topics+'</h2><p>'+t.topicsDesc+'</p>'+statsHtml(all);bindTopicCards();}
function riskList(rows){if(!rows.length)return "<p>"+t.noRisk+"</p>";var out='<ul class="mini-list">';for(var i=0;i<rows.length;i++)out+='<li><button data-id="'+html(rows[i].id)+'" type="button">'+html(rows[i].title)+'</button></li>';return out+"</ul>";}
function statsHtml(rows){var official=0,max=0;for(var i=0;i<rows.length;i++){if(Number(rows[i].official_source_count||0)>0)official++;if(Number(rows[i].score||0)>max)max=Number(rows[i].score||0);}return '<div class="digest-stats"><div class="stat"><strong>'+rows.length+'</strong><span>'+t.items+'</span></div><div class="stat"><strong>'+official+'</strong><span>'+t.officialCount+'</span></div><div class="stat"><strong>'+max.toFixed(0)+'</strong><span>Top score</span></div></div>';}
function renderDefaultDigest(){var daily=state.daily;document.getElementById("detail").innerHTML='<p class="digest-kicker">AMZ HOT DAILY</p><h2>'+t.daily+'</h2><p>'+t.dailyDesc+'</p><div class="digest-stats" id="digestStats"></div>';renderDigestStats(daily);}
function renderCurrent(){document.getElementById("pageTitle").textContent=t[state.view]||t.selected;if(state.view==="all")renderAll();else if(state.view==="daily")renderDaily();else if(state.view==="topics")renderTopics();else renderSelected();}
function bindDailyClicks(){var rows=document.querySelectorAll(".daily-row");for(var i=0;i<rows.length;i++)rows[i].addEventListener("click",function(){showDetail(this.getAttribute("data-id"));});var mini=document.querySelectorAll(".mini-list button");for(var j=0;j<mini.length;j++)mini[j].addEventListener("click",function(){showDetail(this.getAttribute("data-id"));});}
function bindTopicCards(){var cards=document.querySelectorAll(".topic-card");for(var i=0;i<cards.length;i++)cards[i].addEventListener("click",function(){var tag=this.getAttribute("data-topic");document.getElementById("tagFilter").value=tag;setTopicActive(tag);state.view="all";setView("all");load();});}
function showDetail(id){getJson("/api/clusters/"+encodeURIComponent(id),function(err,d){if(err)return;var b=d.score_breakdown||{},tagHtml2=tagHtml(d.tags),breakHtml="",evi="",rows=d.items||[];for(var k in b)if(Object.prototype.hasOwnProperty.call(b,k))breakHtml+="<div><strong>"+html(k)+"</strong><br>"+html(b[k])+"</div>";for(var j=0;j<rows.length;j++)evi+='<li><a href="'+html(rows[j].url)+'" target="_blank" rel="noreferrer">'+t.readOriginal+'：'+html(rows[j].title)+"</a><p>"+html(rows[j].source_name)+" &#183; "+fmtTime(rows[j].published_at)+" &#183; "+(rows[j].official?t.official:t.unofficial)+"</p></li>";document.getElementById("detail").innerHTML='<p class="digest-kicker">'+t.detail+"</p><h2>"+html(d.title)+"</h2><p>"+html(d.summary||d.title)+'</p><div class="meta">'+tagHtml2+'<span class="tag">score '+html(d.score)+'</span><span class="tag">'+html(d.confidence)+'</span></div><div class="breakdown">'+breakHtml+'</div><ul class="evidence">'+evi+"</ul>";history.replaceState(null,"","/clusters/"+id);});}
function load(){setLoading(true);var tag=document.getElementById("tagFilter").value,limit=state.view==="all"?200:100,ts=Date.now(),url="/api/clusters?sort=time&limit="+limit+(tag?"&tag="+encodeURIComponent(tag):"")+"&_ts="+ts,left=3,data={};function done(n,e,v){if(e){setLoading(false);document.getElementById("status").textContent=t.loadFailed+": "+e.message;return;}data[n]=v;left--;if(left===0){setLoading(false);renderLoaded(data.health,data.daily,data.clusters);}}getJson("/api/health?_ts="+ts,function(e,v){done("health",e,v);});getJson("/api/daily/latest?_ts="+ts,function(e,v){done("daily",e,v);});getJson(url,function(e,v){done("clusters",e,v);});}
function renderLoaded(health,daily,clusters){state.health=health;state.daily=daily;state.clusters=clusters;var latest=health.latest_run;document.getElementById("todayLabel").textContent="AMZ HOT "+fmtDate(new Date());document.getElementById("status").textContent=latest?t.latestRun+": "+latest.kind+" \u00b7 "+latest.status+" \u00b7 "+new Date(latest.created_at).toLocaleString("zh-CN",{hour12:false}):t.notRun;renderCurrent();var m=location.pathname.match(/\/clusters\/(\d+)/);if(m)showDetail(m[1]);}
function refreshNow(){setLoading(true);document.getElementById("status").textContent=t.refreshStatus;postJson("/api/run/refresh?_ts="+Date.now(),function(e,r){if(e){setLoading(false);document.getElementById("status").textContent=t.loadFailed+": "+e.message;return;}history.replaceState(null,"","/");load();});}
function bind(){var vb=document.querySelectorAll(".rail-link[data-view]");for(var i=0;i<vb.length;i++)vb[i].addEventListener("click",function(){setView(this.getAttribute("data-view"));});var tb=document.querySelectorAll(".topic");for(var j=0;j<tb.length;j++)tb[j].addEventListener("click",function(){for(var k=0;k<tb.length;k++)tb[k].classList.remove("active");this.classList.add("active");document.getElementById("tagFilter").value=this.getAttribute("data-tag");if(state.view==="topics")setView("selected");load();});document.getElementById("refreshBtn").addEventListener("click",function(){refreshNow();});document.getElementById("langToggle").addEventListener("click",function(){toggleLang();});document.getElementById("tagFilter").addEventListener("change",function(){setTopicActive(this.value);load();});document.getElementById("dryRunBtn").addEventListener("click",function(){postJson("/api/run/notify?dry_run=true",function(e,r){if(e){alert(e.message);return;}alert(JSON.stringify(r,null,2));});});}
bind();applyLanguage();load();
'''

APP_CSS = r'''
:root{--bg:#faf9f4;--rail:#f4f2ea;--ink:#161616;--muted:#747068;--line:#ded9ce;--soft:#eee9dd;--paper:#fffdf8;--accent:#007185;--hot:#b42318;--tag:#f7f3e9}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,"Segoe UI",Arial,sans-serif;letter-spacing:0}button,select{font:inherit}button{cursor:pointer}.page{min-height:100vh;display:grid;grid-template-columns:226px minmax(0,1fr)}.rail{position:sticky;top:0;height:100vh;padding:26px 18px;border-right:1px solid var(--line);background:var(--rail)}.logo{display:block;color:var(--ink);text-decoration:none;margin-bottom:34px}.logo-main{display:block;font-size:20px;font-weight:850}.logo-sub{display:block;margin-top:5px;color:var(--muted);font-size:12px}.rail-section{margin-top:24px}.rail-section p{margin:0 0 8px;color:var(--muted);font-size:13px}.rail-link{display:block;width:100%;height:34px;padding:0 10px;border:1px solid transparent;border-radius:6px;background:transparent;color:var(--ink);text-align:left}.rail-link:hover,.rail-link.active{background:var(--soft);border-color:var(--line)}.rail-link.utility{background:var(--paper);border-color:var(--line)}.main{padding:30px 34px 60px}.top,.topic-tabs,.content-grid{max-width:1180px;margin-left:auto;margin-right:auto}.top{display:flex;justify-content:space-between;gap:24px;align-items:flex-start;padding-bottom:18px}.date-line{margin:0 0 8px;color:var(--muted);font-size:14px}h1,h2,h3,p{margin:0}h1{font-size:34px;line-height:1.15}.subtitle{margin-top:9px;color:var(--muted);font-size:14px}.top-actions{display:flex;gap:8px}.top-actions select,.top-actions button{height:34px;border:1px solid var(--line);border-radius:6px;background:var(--paper);padding:0 12px;color:var(--ink)}.top-actions button.is-loading{color:var(--muted);background:var(--soft)}.topic-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:18px}.topic{height:32px;padding:0 12px;border:1px solid transparent;border-radius:999px;background:transparent;color:var(--muted)}.topic:hover,.topic.active{color:var(--ink);background:var(--soft);border-color:var(--line)}.content-grid{display:grid;grid-template-columns:minmax(0,1fr) 318px;gap:30px;align-items:start}.stream-head{display:flex;justify-content:space-between;align-items:baseline;gap:16px;padding:13px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}.stream-head h2{font-size:17px}.stream-head span{color:var(--muted);font-size:13px}.stream{display:grid}.day-title{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:18px 0 6px;border-bottom:1px solid var(--line);color:var(--muted);font-size:13px}.day-title span{font-weight:700;color:#4b4740}.day-title em{font-style:normal;color:var(--muted)}.news-item{display:grid;grid-template-columns:52px minmax(0,1fr) 44px;gap:14px;padding:13px 0 15px;border-bottom:1px solid var(--line)}.news-item.compact{grid-template-columns:46px minmax(0,1fr) 42px;padding:10px 0}.news-item:hover h3,.daily-row:hover h3{color:var(--accent)}.news-time{color:var(--muted);font-size:13px;line-height:1.4}.news-item h3{font-size:16px;line-height:1.38}.news-item h3 a,.daily-row h3 a{color:inherit;text-decoration:none}.news-item h3 a:hover,.daily-row h3 a:hover{color:var(--accent)}.news-item.compact h3{font-size:15px}.summary{margin-top:7px;color:#444039;font-size:14px;line-height:1.55}.meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}.tag{display:inline-flex;align-items:center;height:23px;padding:0 8px;border-radius:999px;border:1px solid var(--line);background:var(--tag);color:var(--muted);font-size:12px}.score{justify-self:end;display:grid;place-items:center;width:42px;height:30px;border-radius:6px;background:var(--accent);color:white;font-size:14px;font-weight:800}.score.hot{background:var(--hot)}.digest{position:sticky;top:24px;padding:18px 0 0;border-top:1px solid var(--line)}.digest-kicker{margin-bottom:8px;color:var(--muted);font-size:12px}.digest h2{font-size:22px;line-height:1.25}.digest p{margin-top:10px;color:#48443c;font-size:14px;line-height:1.55}.digest-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:18px}.stat{padding:10px 8px;border:1px solid var(--line);border-radius:6px;background:var(--paper)}.stat strong{display:block;font-size:20px}.stat span{display:block;margin-top:5px;color:var(--muted);font-size:12px}.breakdown{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:14px}.breakdown div{border:1px solid var(--line);border-radius:6px;background:var(--paper);padding:8px;font-size:13px}.evidence{list-style:none;padding:0;margin:14px 0 0}.evidence li{padding:10px 0;border-top:1px solid var(--line)}.evidence a{color:var(--accent);text-decoration:none;overflow-wrap:anywhere}.view-all{grid-template-columns:minmax(0,1fr) 280px}.view-daily{grid-template-columns:minmax(0,1fr) 340px}.view-topics{grid-template-columns:minmax(0,1fr) 300px}.daily-hero{padding:20px 0 18px;border-bottom:1px solid var(--line)}.daily-hero p{color:var(--muted);font-size:12px;margin-bottom:8px}.daily-hero h2{font-size:24px;line-height:1.28}.daily-hero span{display:block;margin-top:8px;color:var(--muted);font-size:13px}.daily-row{display:grid;grid-template-columns:34px minmax(0,1fr) 44px;gap:14px;padding:16px 0;border-bottom:1px solid var(--line);background:transparent;text-align:left}.daily-row strong{color:var(--muted);font-size:18px}.daily-row h3{font-size:17px;line-height:1.35}.daily-row p{margin-top:7px;color:#444039;font-size:14px;line-height:1.55}.topic-board{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding-top:16px}.topic-card{min-height:138px;border:1px solid var(--line);border-radius:8px;background:var(--paper);padding:14px;text-align:left;color:var(--ink)}.topic-card:hover{border-color:var(--accent)}.topic-card span{display:block;color:var(--muted);font-size:13px}.topic-card strong{display:block;margin-top:8px;font-size:28px}.topic-card p{margin-top:10px;color:#48443c;font-size:13px;line-height:1.45}.mini-list{list-style:none;padding:0;margin:14px 0 0}.mini-list li{border-top:1px solid var(--line)}.mini-list button{width:100%;padding:10px 0;border:0;background:transparent;text-align:left;color:var(--ink);line-height:1.35}@media(max-width:960px){.page{grid-template-columns:1fr}.rail{position:static;height:auto;border-right:0;border-bottom:1px solid var(--line)}.rail-section{display:inline-block;vertical-align:top;min-width:190px;margin-right:14px}.content-grid,.view-all,.view-daily,.view-topics{grid-template-columns:1fr}.digest{position:static}.topic-board{grid-template-columns:1fr}}@media(max-width:620px){.main,.rail{padding-left:16px;padding-right:16px}.top{display:grid}.news-item,.news-item.compact{grid-template-columns:minmax(0,1fr) 42px}.news-time{grid-column:1/-1}.topic-board{grid-template-columns:1fr}}
'''


def _schedule_daily() -> object | None:
    if os.getenv("VERCEL"):
        return None
    if AsyncIOScheduler is None or CronTrigger is None:
        return None
    hour, minute = settings.daily_send_time.split(":", 1)
    scheduler = AsyncIOScheduler(timezone=settings.timezone)
    scheduler.add_job(
        lambda: asyncio.create_task(run_once(db, settings)),
        CronTrigger(hour=int(hour), minute=int(minute), timezone=settings.timezone),
        id="daily_amazon_hotbot",
        replace_existing=True,
    )
    scheduler.start()
    return scheduler


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init()
    scheduler = _schedule_daily()
    yield
    if scheduler:
        scheduler.shutdown(wait=False)


app = FastAPI(title="Amazon Hotbot", version="0.1.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
async def index() -> Response:
    html = (static_dir / "index.html").read_text(encoding="utf-8")
    return Response(
        html,
        media_type="text/html; charset=utf-8",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.get("/app.js")
async def app_js() -> Response:
    return Response(
        APP_JS,
        media_type="text/javascript; charset=utf-8",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.get("/styles.css")
async def styles_css() -> Response:
    return Response(
        APP_CSS,
        media_type="text/css; charset=utf-8",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.get("/clusters/{cluster_id}")
async def cluster_page(cluster_id: int) -> Response:
    html = (static_dir / "index.html").read_text(encoding="utf-8")
    return Response(
        html,
        media_type="text/html; charset=utf-8",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.get("/api/health")
async def health() -> dict:
    latest = db.latest_run()
    return {
        "ok": True,
        "daily_send_time": settings.daily_send_time,
        "timezone": settings.timezone,
        "dry_run": settings.dry_run,
        "feishu_configured": bool(settings.feishu_webhook_url),
        "latest_run": row_to_dict(latest) if latest else None,
    }


@app.get("/api/items")
async def items(
    limit: Annotated[int, Query(ge=1, le=500)] = 200,
    tag: str | None = None,
    source: str | None = None,
    official: bool | None = None,
) -> list[dict]:
    return [row_to_dict(row) for row in db.get_items(limit=limit, tag=tag, source=source, official=official)]


@app.get("/api/clusters")
async def clusters(
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    tag: str | None = None,
    sort: Annotated[str, Query(pattern="^(time|score)$")] = "time",
) -> list[dict]:
    return [row_to_dict(row) for row in db.get_clusters(limit=limit, tag=tag, sort=sort)]


@app.get("/api/clusters/{cluster_id}")
async def cluster_detail(cluster_id: int) -> dict:
    cluster, rows = db.get_cluster(cluster_id)
    if cluster is None:
        raise HTTPException(status_code=404, detail="Cluster not found")
    data = row_to_dict(cluster)
    data["items"] = [row_to_dict(row) for row in rows]
    return data


@app.get("/api/daily/latest")
async def daily_latest() -> dict:
    clusters = [row_to_dict(row) for row in db.get_clusters(limit=100, sort="score")]
    top = [cluster for cluster in clusters if is_actionable_cluster(cluster)][:10]
    high_risk = [cluster for cluster in top if {"policy", "api", "account", "fba"} & set(cluster.get("tags", []))]
    return {"top": top, "high_risk": high_risk[:5]}


@app.post("/api/run/fetch")
async def run_fetch() -> dict:
    return await fetch_step(db, settings)


@app.post("/api/run/process")
async def run_process() -> dict:
    return process_step(db)


@app.post("/api/run/refresh")
async def run_refresh() -> dict:
    fetch_stats = await fetch_step(db, settings)
    process_stats = process_step(db)
    return {"fetch": fetch_stats, "process": process_stats}


@app.post("/api/run/notify")
async def run_notify(dry_run: bool = True) -> dict:
    return await notify_daily(db, settings, dry_run=dry_run)


@app.post("/api/run/once")
async def run_all(dry_run: bool = True) -> dict:
    return await run_once(db, settings, dry_run=dry_run)
