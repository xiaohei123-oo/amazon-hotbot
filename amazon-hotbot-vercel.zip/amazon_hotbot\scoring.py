from __future__ import annotations

import math
from datetime import datetime, timezone


TAG_IMPACT = {
    "policy": 22,
    "api": 20,
    "account": 20,
    "fba": 17,
    "listing": 16,
    "ads": 14,
    "prime": 14,
    "brand": 10,
}


def time_decay(published_at: datetime, tags: list[str], now: datetime | None = None) -> float:
    now = now or datetime.now(timezone.utc)
    age_hours = max((now - published_at).total_seconds() / 3600, 0)
    half_life = 72 if {"policy", "api", "account", "fba"} & set(tags) else 36
    return math.pow(0.5, age_hours / half_life)


def score_cluster(
    source_weights: list[float],
    tags: list[str],
    first_seen_at: datetime,
    last_seen_at: datetime,
    official_count: int,
    now: datetime | None = None,
) -> tuple[float, dict[str, float]]:
    now = now or datetime.now(timezone.utc)
    source_strength = min(sum(source_weights) * 11, 30)
    corroboration = min(max(len(source_weights) - 1, 0) * 8, 20)
    official = min(official_count * 10, 20)
    impact = max([TAG_IMPACT.get(tag, 6) for tag in tags] or [6])
    decay = time_decay(last_seen_at, tags, now)
    novelty = 10 if (now - first_seen_at).total_seconds() < 24 * 3600 else 4
    raw = source_strength + corroboration + official + impact + novelty
    score = round(min(raw * (0.58 + 0.42 * decay), 100), 1)
    return score, {
        "source_strength": round(source_strength, 1),
        "corroboration": round(corroboration, 1),
        "official": round(official, 1),
        "impact": round(impact, 1),
        "time_decay": round(decay, 3),
        "novelty": round(novelty, 1),
    }


def confidence_for(source_count: int, official_count: int) -> str:
    if official_count >= 1 and source_count >= 2:
        return "high"
    if official_count >= 1:
        return "medium"
    if source_count >= 3:
        return "medium"
    return "low"
