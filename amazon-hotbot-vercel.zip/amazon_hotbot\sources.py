from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from urllib.parse import urljoin

import httpx

from .models import Item, Source
from .normalize import clean_text, detect_language, normalize_url, tag_text


DEFAULT_SOURCES: list[Source] = [
    Source("sell_blog", "Amazon Selling Partner Blog", "https://sell.amazon.com/blog", "html", "seller", "official", True, 1.35),
    Source("sp_api", "Amazon SP-API Announcements", "https://developer-docs.amazon.com/sp-api/changelog", "html", "api", "official", True, 1.45),
    Source("ads_api", "Amazon Ads API Release Notes", "https://advertising.amazon.com/API/docs/en-us/info/release-notes", "html", "ads", "official", True, 1.30),
    Source("newsroom", "Amazon News", "https://www.aboutamazon.com/news", "html", "company", "official", True, 1.10),
    Source("seller_forums", "Amazon Seller Forums", "https://sellercentral.amazon.com/seller-forums", "html", "seller", "community", False, 0.85),
]


class LinkTextParser(HTMLParser):
    def __init__(self, base_url: str) -> None:
        super().__init__()
        self.base_url = base_url
        self._href: str | None = None
        self._text: list[str] = []
        self.links: list[tuple[str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        attrs_dict = dict(attrs)
        href = attrs_dict.get("href")
        if href:
            self._href = urljoin(self.base_url, href)
            self._text = []

    def handle_data(self, data: str) -> None:
        if self._href:
            self._text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href:
            text = clean_text(" ".join(self._text))
            if len(text) >= 12:
                self.links.append((text, normalize_url(self._href)))
            self._href = None
            self._text = []


def parse_date(value: str | None) -> datetime:
    if not value:
        return datetime.now(timezone.utc)
    try:
        parsed = parsedate_to_datetime(value)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except Exception:
        pass
    for fmt in ("%b %d, %Y", "%B %d, %Y", "%Y-%m-%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return datetime.now(timezone.utc)


def _item_from_parts(source: Source, title: str, url: str, summary: str = "", published: str | None = None) -> Item:
    text = clean_text(f"{title} {summary}")
    return Item(
        source_id=source.id,
        source_name=source.name,
        title=clean_text(html.unescape(title))[:280],
        url=normalize_url(url),
        published_at=parse_date(published),
        summary=clean_text(html.unescape(summary))[:800],
        raw_text=text,
        language=detect_language(text),
        tags=tag_text(text, source.category),
        official=source.official,
        source_weight=source.weight,
    )


def parse_rss(source: Source, body: str) -> list[Item]:
    root = ET.fromstring(body)
    items: list[Item] = []
    for node in root.findall(".//item") + root.findall(".//{http://www.w3.org/2005/Atom}entry"):
        title = node.findtext("title") or node.findtext("{http://www.w3.org/2005/Atom}title") or ""
        link = node.findtext("link") or ""
        atom_link = node.find("{http://www.w3.org/2005/Atom}link")
        if atom_link is not None and atom_link.attrib.get("href"):
            link = atom_link.attrib["href"]
        summary = node.findtext("description") or node.findtext("summary") or node.findtext("{http://www.w3.org/2005/Atom}summary") or ""
        published = node.findtext("pubDate") or node.findtext("published") or node.findtext("{http://www.w3.org/2005/Atom}published")
        if title and link:
            items.append(_item_from_parts(source, title, urljoin(source.url, link), summary, published))
    return items


def parse_html(source: Source, body: str) -> list[Item]:
    parser = LinkTextParser(source.url)
    parser.feed(body)
    seen: set[str] = set()
    items: list[Item] = []
    deny_titles = {
        "conditions of use",
        "privacy notice",
        "privacy policy",
        "terms of service",
        "sustainability",
        "artificial intelligence",
        "entertainment",
        "español - us",
        "english - us",
        "learn more",
        "home",
        "search",
        "find products to sell",
        "seller central",
        "policies and agreements",
        "developer hub",
        "release notes",
        "api reference",
        "code samples",
        "jump to content",
        "inventory management",
        "documentation",
        "how to sell online get an overview for running an ecommerce business",
    }
    required_keywords = (
        "seller",
        "selling",
        "sell ",
        "fba",
        "sp-api",
        "ads",
        "advertising",
        "policy",
        "prime day",
        "listing",
        "brand registry",
        "customer service",
        "fulfillment",
        "inventory",
        "attribute",
        "enumeration",
        "release",
        "api",
        "campaign",
        "sponsored",
        "marketplace",
    )
    for title, url in parser.links:
        low = f"{title} {url}".lower()
        if url in seen or any(skip in low for skip in ("privacy", "terms", "login", "sign in", "feedback")):
            continue
        if title.lower() in deny_titles:
            continue
        if not any(keyword in low for keyword in required_keywords):
            continue
        seen.add(url)
        items.append(_item_from_parts(source, title, url))
    return items[:40]


async def fetch_source(source: Source, timeout: float = 20.0) -> list[Item]:
    headers = {"User-Agent": "AmazonHotbot/0.1 (+public news monitor)"}
    async with httpx.AsyncClient(follow_redirects=True, timeout=timeout, headers=headers) as client:
        response = await client.get(source.url)
        response.raise_for_status()
        body = response.text
    content_type = response.headers.get("content-type", "")
    if source.kind == "rss" or "xml" in content_type or re.search(r"<(rss|feed)[\s>]", body[:500], re.I):
        return parse_rss(source, body)
    return parse_html(source, body)


async def fetch_all(sources: list[Source] | None = None, timeout: float = 20.0) -> tuple[list[Item], list[dict[str, str]]]:
    all_items: list[Item] = []
    errors: list[dict[str, str]] = []
    for source in sources or DEFAULT_SOURCES:
        try:
            all_items.extend(await fetch_source(source, timeout))
        except Exception as exc:
            errors.append({"source": source.name, "error": str(exc)})
    return all_items, errors
