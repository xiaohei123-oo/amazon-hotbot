from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _load_dotenv() -> None:
    for env_path in (Path(".env"), Path(".env.local")):
        if not env_path.exists():
            continue
        content = env_path.read_bytes().decode("utf-8", errors="ignore")
        content = "".join(ch for ch in content if ch in "\r\n\t" or 32 <= ord(ch) <= 126)
        for raw_line in content.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            clean_key = key.strip()
            clean_value = value.strip().strip('"').strip("'")
            if clean_value:
                os.environ[clean_key] = clean_value


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    database_url: str = "data/hotbot.sqlite3"
    feishu_webhook_url: str = ""
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4.1-mini"
    daily_send_time: str = "09:00"
    timezone: str = "Asia/Shanghai"
    dry_run: bool = True
    request_timeout_seconds: float = 20.0


def get_settings() -> Settings:
    _load_dotenv()
    default_database_url = "/tmp/hotbot.sqlite3" if os.getenv("VERCEL") else "data/hotbot.sqlite3"
    return Settings(
        database_url=os.getenv("DATABASE_URL", default_database_url),
        feishu_webhook_url=os.getenv("FEISHU_WEBHOOK_URL", ""),
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        openai_base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        openai_model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        daily_send_time=os.getenv("DAILY_SEND_TIME", "09:00"),
        timezone=os.getenv("TIMEZONE", "Asia/Shanghai"),
        dry_run=_bool("DRY_RUN", True),
        request_timeout_seconds=float(os.getenv("REQUEST_TIMEOUT_SECONDS", "20")),
    )
