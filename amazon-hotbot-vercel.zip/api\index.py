from amazon_hotbot.web import app
