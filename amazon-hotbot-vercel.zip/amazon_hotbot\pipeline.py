from __future__ import annotations

from .cluster import rebuild_clusters
from .config import Settings
from .db import Database
from .notify import notify_daily
from .sources import fetch_all


async def fetch_step(db: Database, settings: Settings) -> dict:
    items, errors = await fetch_all(timeout=settings.request_timeout_seconds)
    inserted = db.upsert_items(items)
    stats = {"fetched": len(items), "inserted": inserted, "errors": errors}
    db.add_run("fetch", "ok" if not errors else "partial", stats)
    return stats


def process_step(db: Database) -> dict:
    stats = rebuild_clusters(db)
    db.add_run("process", "ok", stats)
    return stats


async def run_once(db: Database, settings: Settings, dry_run: bool | None = None) -> dict:
    fetch_stats = await fetch_step(db, settings)
    process_stats = process_step(db)
    notify_result = await notify_daily(db, settings, dry_run)
    return {"fetch": fetch_stats, "process": process_stats, "notify": notify_result}
