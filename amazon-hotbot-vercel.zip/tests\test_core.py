from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

from amazon_hotbot.cluster import rebuild_clusters
from amazon_hotbot.db import Database
from amazon_hotbot.models import Item
from amazon_hotbot.normalize import normalize_url
from amazon_hotbot.notify import build_feishu_payload
from amazon_hotbot.scoring import score_cluster, time_decay


def test_normalize_url_removes_tracking() -> None:
    assert normalize_url("HTTPS://Example.com/Path/?utm_source=x&a=1#frag") == "https://example.com/Path?a=1"


def test_time_decay_policy_half_life_is_longer() -> None:
    now = datetime(2026, 7, 6, tzinfo=timezone.utc)
    published = now - timedelta(hours=48)
    assert time_decay(published, ["policy"], now) > time_decay(published, ["marketplace"], now)


def test_score_cluster_rewards_official_and_multiple_sources() -> None:
    now = datetime(2026, 7, 6, tzinfo=timezone.utc)
    score, breakdown = score_cluster([1.4, 1.0], ["api"], now, now, official_count=1, now=now)
    assert score > 50
    assert breakdown["official"] == 10
    assert breakdown["corroboration"] == 8


def test_rebuild_clusters_merges_related_items(tmp_path) -> None:
    db = Database(str(tmp_path / "hotbot.sqlite3"))
    db.init()
    now = datetime(2026, 7, 6, tzinfo=timezone.utc)
    db.upsert_items(
        [
            Item(
                source_id="sp_api",
                source_name="Amazon SP-API",
                title="Update: June updates to listing attribute usage and enumeration values",
                url="https://developer-docs.amazon.com/sp-api/changelog/june",
                published_at=now,
                summary="Amazon will update attribute usage and enumeration values.",
                official=True,
                source_weight=1.4,
                tags=["api", "listing"],
            ),
            Item(
                source_id="media",
                source_name="Marketplace Media",
                title="Amazon listing attribute enumeration values update starts in June",
                url="https://example.com/amazon-listing-update",
                published_at=now - timedelta(hours=2),
                summary="The listing attribute update affects product types across marketplaces.",
                official=False,
                source_weight=0.8,
                tags=["listing"],
            ),
        ]
    )
    stats = rebuild_clusters(db)
    clusters = db.get_clusters()
    cluster, items = db.get_cluster(clusters[0]["id"])
    assert stats["clusters"] == 1
    assert cluster is not None
    assert len(items) == 2
    assert cluster["official_source_count"] == 1


def test_feishu_payload_contains_top_10_only() -> None:
    clusters = [
        {
            "id": i,
            "score": 90 - i,
            "title": f"事件 {i}",
            "tags": ["policy"],
            "confidence": "high",
            "source_count": 2,
            "summary": "摘要",
        }
        for i in range(12)
    ]
    payload = build_feishu_payload(clusters)
    text = payload["content"]["text"]
    assert "Amazon 热点日报" in text
    assert "10. " in text
    assert "11. " not in text
