from __future__ import annotations

from collections import Counter
from datetime import datetime
import json

from .db import Database, parse_dt
from .models import Cluster
from .normalize import canonical_title, tag_text, tokenize
from .scoring import confidence_for, score_cluster


def jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _similar(item: dict, group: list[dict]) -> bool:
    item_tokens = tokenize(f"{item['title']} {item['summary']}")
    item_time = parse_dt(item["published_at"])
    for other in group:
        other_tokens = tokenize(f"{other['title']} {other['summary']}")
        other_time = parse_dt(other["published_at"])
        hours = abs((item_time - other_time).total_seconds()) / 3600
        if hours <= 120 and jaccard(item_tokens, other_tokens) >= 0.34:
            return True
        if hours <= 72 and canonical_title(item["title"])[:48] == canonical_title(other["title"])[:48]:
            return True
    return False


def _cluster_summary(items: list[dict]) -> str:
    official = [item for item in items if item["official"]]
    lead = (official or items)[0]
    if lead["summary"]:
        return lead["summary"][:360]
    names = ", ".join(sorted({item["source_name"] for item in items})[:3])
    return f"{lead['title']}。证据源：{names}。"


def rebuild_clusters(db: Database) -> dict[str, int]:
    rows = [dict(row) for row in db.get_items(limit=1000)]
    rows.sort(key=lambda row: row["published_at"], reverse=True)
    groups: list[list[dict]] = []
    for row in rows:
        matched = False
        for group in groups:
            if _similar(row, group):
                group.append(row)
                matched = True
                break
        if not matched:
            groups.append([row])

    clusters: list[Cluster] = []
    item_cluster_map: dict[int, int] = {}
    for index, group in enumerate(groups, start=1):
        group.sort(key=lambda row: (row["official"], row["source_weight"], row["published_at"]), reverse=True)
        tag_counter: Counter[str] = Counter()
        weights: list[float] = []
        times: list[datetime] = []
        official_count = 0
        for row in group:
            saved_tags = json.loads(row.get("tags_json") or "[]")
            tags = list(dict.fromkeys(saved_tags + tag_text(f"{row['title']} {row['summary']}")))
            tag_counter.update(tags)
            weights.append(float(row["source_weight"]))
            times.append(parse_dt(row["published_at"]))
            official_count += int(row["official"])
            item_cluster_map[int(row["id"])] = index
        tags = [tag for tag, _ in tag_counter.most_common(4)]
        first_seen = min(times)
        last_seen = max(times)
        score, breakdown = score_cluster(weights, tags, first_seen, last_seen, official_count)
        clusters.append(
            Cluster(
                id=None,
                title=group[0]["title"],
                summary=_cluster_summary(group),
                tags=tags,
                score=score,
                score_breakdown=breakdown,
                first_seen_at=first_seen,
                last_seen_at=last_seen,
                source_count=len({row["source_id"] for row in group}),
                official_source_count=official_count,
                confidence=confidence_for(len(group), official_count),
            )
        )

    clusters_with_maps = list(enumerate(clusters, start=1))
    clusters_with_maps.sort(key=lambda pair: pair[1].score, reverse=True)
    old_to_new = {old: new for new, (old, _) in enumerate(clusters_with_maps, start=1)}
    sorted_clusters = [cluster for _, cluster in clusters_with_maps]
    remapped = {item_id: old_to_new[temp_id] for item_id, temp_id in item_cluster_map.items()}
    db.replace_clusters(sorted_clusters, remapped)
    return {"items": len(rows), "clusters": len(sorted_clusters)}
