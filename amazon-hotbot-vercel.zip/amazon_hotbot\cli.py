from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .config import get_settings
from .db import Database
from .notify import notify_daily
from .pipeline import fetch_step, process_step, run_once


def _db() -> tuple[Database, object]:
    settings = get_settings()
    db = Database(settings.database_url)
    db.init()
    return db, settings


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="Amazon Hotbot")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("fetch")
    sub.add_parser("process")
    notify = sub.add_parser("notify")
    notify.add_argument("--dry-run", action="store_true")
    run_once_parser = sub.add_parser("run-once")
    run_once_parser.add_argument("--dry-run", action="store_true")
    serve = sub.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    db, settings = _db()
    if args.command == "fetch":
        result = asyncio.run(fetch_step(db, settings))
    elif args.command == "process":
        result = process_step(db)
    elif args.command == "notify":
        result = asyncio.run(notify_daily(db, settings, dry_run=args.dry_run or None))
    elif args.command == "run-once":
        result = asyncio.run(run_once(db, settings, dry_run=args.dry_run or None))
    elif args.command == "serve":
        import uvicorn

        uvicorn.run("amazon_hotbot.web:app", host=args.host, port=args.port, reload=False)
        return
    else:
        raise SystemExit(f"Unknown command: {args.command}")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
