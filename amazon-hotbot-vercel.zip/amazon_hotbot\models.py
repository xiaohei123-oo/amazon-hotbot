from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class Source:
    id: str
    name: str
    url: str
    kind: str
    category: str
    source_type: str
    official: bool
    weight: float


@dataclass
class Item:
    source_id: str
    source_name: str
    title: str
    url: str
    published_at: datetime
    summary: str = ""
    raw_text: str = ""
    language: str = "en"
    tags: list[str] = field(default_factory=list)
    official: bool = False
    source_weight: float = 1.0


@dataclass
class Cluster:
    id: int | None
    title: str
    summary: str
    tags: list[str]
    score: float
    score_breakdown: dict[str, float]
    first_seen_at: datetime
    last_seen_at: datetime
    source_count: int
    official_source_count: int
    confidence: str
