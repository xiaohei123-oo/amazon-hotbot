from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import Cluster, Item


def _dt(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat()


def parse_dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


class Database:
    def __init__(self, database_url: str) -> None:
        self.path = Path(database_url.removeprefix("sqlite:///"))
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def init(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_id TEXT NOT NULL,
                    source_name TEXT NOT NULL,
                    title TEXT NOT NULL,
                    url TEXT NOT NULL UNIQUE,
                    published_at TEXT NOT NULL,
                    summary TEXT NOT NULL DEFAULT '',
                    raw_text TEXT NOT NULL DEFAULT '',
                    language TEXT NOT NULL DEFAULT 'en',
                    tags_json TEXT NOT NULL DEFAULT '[]',
                    official INTEGER NOT NULL DEFAULT 0,
                    source_weight REAL NOT NULL DEFAULT 1,
                    cluster_id INTEGER,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS clusters (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    summary TEXT NOT NULL DEFAULT '',
                    tags_json TEXT NOT NULL DEFAULT '[]',
                    score REAL NOT NULL DEFAULT 0,
                    score_breakdown_json TEXT NOT NULL DEFAULT '{}',
                    first_seen_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    source_count INTEGER NOT NULL DEFAULT 0,
                    official_source_count INTEGER NOT NULL DEFAULT 0,
                    confidence TEXT NOT NULL DEFAULT 'low',
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    status TEXT NOT NULL,
                    stats_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                """
            )

    def upsert_items(self, items: list[Item]) -> int:
        inserted = 0
        now = _dt(datetime.now(timezone.utc))
        with self.connect() as conn:
            for item in items:
                cur = conn.execute(
                    """
                    INSERT OR IGNORE INTO items
                    (source_id, source_name, title, url, published_at, summary, raw_text, language,
                     tags_json, official, source_weight, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        item.source_id,
                        item.source_name,
                        item.title,
                        item.url,
                        _dt(item.published_at),
                        item.summary,
                        item.raw_text,
                        item.language,
                        json.dumps(item.tags, ensure_ascii=False),
                        1 if item.official else 0,
                        item.source_weight,
                        now,
                    ),
                )
                inserted += cur.rowcount
        return inserted

    def get_unclustered_items(self) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute("SELECT * FROM items WHERE cluster_id IS NULL ORDER BY published_at DESC"))

    def get_items(self, limit: int = 200, tag: str | None = None, source: str | None = None, official: bool | None = None) -> list[sqlite3.Row]:
        clauses: list[str] = []
        params: list[Any] = []
        if tag:
            clauses.append("tags_json LIKE ?")
            params.append(f"%{tag}%")
        if source:
            clauses.append("source_id = ?")
            params.append(source)
        if official is not None:
            clauses.append("official = ?")
            params.append(1 if official else 0)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        with self.connect() as conn:
            return list(conn.execute(f"SELECT * FROM items {where} ORDER BY published_at DESC LIMIT ?", (*params, limit)))

    def get_clusters(self, limit: int = 100, tag: str | None = None, sort: str = "score") -> list[sqlite3.Row]:
        where = "WHERE tags_json LIKE ?" if tag else ""
        params: tuple[Any, ...] = (f"%{tag}%", limit) if tag else (limit,)
        order = "last_seen_at DESC, score DESC" if sort == "time" else "score DESC, last_seen_at DESC"
        with self.connect() as conn:
            return list(conn.execute(f"SELECT * FROM clusters {where} ORDER BY {order} LIMIT ?", params))

    def get_cluster(self, cluster_id: int) -> tuple[sqlite3.Row | None, list[sqlite3.Row]]:
        with self.connect() as conn:
            cluster = conn.execute("SELECT * FROM clusters WHERE id = ?", (cluster_id,)).fetchone()
            items = list(conn.execute("SELECT * FROM items WHERE cluster_id = ? ORDER BY published_at DESC", (cluster_id,)))
            return cluster, items

    def replace_clusters(self, clusters: list[Cluster], item_cluster_map: dict[int, int]) -> None:
        now = _dt(datetime.now(timezone.utc))
        with self.connect() as conn:
            conn.execute("DELETE FROM clusters")
            id_map: dict[int, int] = {}
            for temp_id, cluster in enumerate(clusters, start=1):
                cur = conn.execute(
                    """
                    INSERT INTO clusters
                    (title, summary, tags_json, score, score_breakdown_json, first_seen_at, last_seen_at,
                     source_count, official_source_count, confidence, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cluster.title,
                        cluster.summary,
                        json.dumps(cluster.tags, ensure_ascii=False),
                        cluster.score,
                        json.dumps(cluster.score_breakdown, ensure_ascii=False),
                        _dt(cluster.first_seen_at),
                        _dt(cluster.last_seen_at),
                        cluster.source_count,
                        cluster.official_source_count,
                        cluster.confidence,
                        now,
                    ),
                )
                id_map[temp_id] = int(cur.lastrowid)
            conn.execute("UPDATE items SET cluster_id = NULL")
            for item_id, temp_cluster_id in item_cluster_map.items():
                conn.execute("UPDATE items SET cluster_id = ? WHERE id = ?", (id_map[temp_cluster_id], item_id))

    def add_run(self, kind: str, status: str, stats: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO runs (kind, status, stats_json, created_at) VALUES (?, ?, ?, ?)",
                (kind, status, json.dumps(stats, ensure_ascii=False), _dt(datetime.now(timezone.utc))),
            )

    def latest_run(self) -> sqlite3.Row | None:
        with self.connect() as conn:
            return conn.execute("SELECT * FROM runs ORDER BY created_at DESC LIMIT 1").fetchone()


def row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    data = dict(row)
    for key in ("tags_json", "score_breakdown_json", "stats_json"):
        if key in data:
            target = key.removesuffix("_json")
            data[target] = json.loads(data.pop(key) or "{}")
    return data
