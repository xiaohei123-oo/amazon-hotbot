from __future__ import annotations

import base64
import json
import os
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
DEPLOYMENT_NAME = os.getenv("VERCEL_PROJECT_NAME", "amazon-hotbot")
TOKEN = os.getenv("VERCEL_TOKEN")
REQUIREMENTS_TXT = """fastapi>=0.115.0
uvicorn[standard]>=0.30.0
httpx>=0.27.0
apscheduler>=3.10.4
python-dotenv>=1.0.1
tzdata>=2025.2
"""

INCLUDE = [
    "api",
    "amazon_hotbot",
    "requirements.txt",
    "README.md",
    "vercel.json",
]

SKIP_PARTS = {"__pycache__", ".pytest_cache"}
SKIP_SUFFIXES = {".pyc", ".sqlite3", ".db"}


def iter_files() -> list[Path]:
    files: list[Path] = []
    for item in INCLUDE:
        path = ROOT / item
        if path.is_file():
            files.append(path)
            continue
        for child in path.rglob("*"):
            if not child.is_file():
                continue
            if any(part in SKIP_PARTS for part in child.parts):
                continue
            if child.suffix in SKIP_SUFFIXES:
                continue
            files.append(child)
    return files


def request_json(url: str, payload: dict) -> dict:
    body = json.dumps(payload).encode("utf-8")
    request = Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=120) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Vercel API error {exc.code}: {detail}") from exc


def main() -> int:
    if not TOKEN:
        print("Missing VERCEL_TOKEN environment variable.", file=sys.stderr)
        return 2

    files = []
    for path in iter_files():
        rel = path.relative_to(ROOT).as_posix()
        data = REQUIREMENTS_TXT.encode("utf-8") if rel == "requirements.txt" else path.read_bytes()
        files.append(
            {
                "file": rel,
                "data": base64.b64encode(data).decode("ascii"),
                "encoding": "base64",
            }
        )

    payload = {
        "name": DEPLOYMENT_NAME,
        "target": "production",
        "files": files,
        "projectSettings": {
            "framework": None,
            "buildCommand": None,
            "outputDirectory": None,
            "installCommand": "pip install -r requirements.txt",
        },
    }
    result = request_json("https://api.vercel.com/v13/deployments", payload)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    url = result.get("url")
    if url:
        print(f"\nDeployment URL: https://{url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
