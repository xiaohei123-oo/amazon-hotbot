from __future__ import annotations

import base64
import json
import os
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
TOKEN = os.getenv("GITHUB_TOKEN")
REPO = os.getenv("GITHUB_REPO", "amazon-hotbot")
OWNER = os.getenv("GITHUB_OWNER")
PRIVATE = os.getenv("GITHUB_PRIVATE", "false").lower() in {"1", "true", "yes", "on"}
BRANCH = os.getenv("GITHUB_BRANCH", "main")

INCLUDE = [
    "api",
    "amazon_hotbot",
    "scripts/deploy_vercel.py",
    "scripts/configure_vercel_env.py",
    "scripts/publish_github.py",
    "requirements.txt",
    "README.md",
    "vercel.json",
    ".vercelignore",
    ".gitignore",
]
SKIP_PARTS = {"__pycache__", ".pytest_cache"}
SKIP_SUFFIXES = {".pyc", ".sqlite3", ".db"}
REQUIREMENTS_TXT = """fastapi>=0.115.0
uvicorn[standard]>=0.30.0
httpx>=0.27.0
apscheduler>=3.10.4
python-dotenv>=1.0.1
tzdata>=2025.2
"""


def api(method: str, path: str, payload: dict | None = None) -> dict:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = Request(
        f"https://api.github.com{path}",
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
            "User-Agent": "amazon-hotbot-publisher",
        },
    )
    try:
        with urlopen(request, timeout=120) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API error {exc.code} {method} {path}: {detail}") from exc


def try_api(method: str, path: str, payload: dict | None = None) -> tuple[int, dict]:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = Request(
        f"https://api.github.com{path}",
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
            "User-Agent": "amazon-hotbot-publisher",
        },
    )
    try:
        with urlopen(request, timeout=120) as response:
            raw = response.read().decode("utf-8")
            return response.status, json.loads(raw) if raw else {}
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        return exc.code, json.loads(raw) if raw else {"message": raw}


def iter_files() -> list[Path]:
    files: list[Path] = []
    for item in INCLUDE:
        path = ROOT / item
        if not path.exists():
            continue
        if path.is_file():
            files.append(path)
            continue
        for child in path.rglob("*"):
            if not child.is_file():
                continue
            if any(part in SKIP_PARTS for part in child.parts):
                continue
            if child.suffix in SKIP_SUFFIXES:
                continue
            files.append(child)
    return files


def file_bytes(path: Path) -> bytes:
    rel = path.relative_to(ROOT).as_posix()
    if rel == "requirements.txt":
        return REQUIREMENTS_TXT.encode("utf-8")
    return path.read_bytes()


def ensure_repo(owner: str) -> dict:
    status, repo = try_api("GET", f"/repos/{owner}/{REPO}")
    if status == 200:
        return repo
    if status != 404:
        raise RuntimeError(f"Unexpected repo lookup response {status}: {repo}")
    return api(
        "POST",
        "/user/repos",
        {
            "name": REPO,
            "private": PRIVATE,
            "description": "Amazon hot news and policy daily bot",
            "auto_init": False,
        },
    )


def main() -> int:
    if not TOKEN:
        print("Missing GITHUB_TOKEN.", file=sys.stderr)
        return 2
    viewer = api("GET", "/user")
    owner = OWNER or viewer["login"]
    repo = ensure_repo(owner)
    full_name = repo["full_name"]

    blobs = []
    for path in iter_files():
        rel = path.relative_to(ROOT).as_posix()
        blob = api(
            "POST",
            f"/repos/{full_name}/git/blobs",
            {
                "content": base64.b64encode(file_bytes(path)).decode("ascii"),
                "encoding": "base64",
            },
        )
        blobs.append({"path": rel, "mode": "100644", "type": "blob", "sha": blob["sha"]})

    status, ref = try_api("GET", f"/repos/{full_name}/git/ref/heads/{BRANCH}")
    parents = []
    base_tree = None
    if status == 200:
        commit_sha = ref["object"]["sha"]
        commit = api("GET", f"/repos/{full_name}/git/commits/{commit_sha}")
        parents = [commit_sha]
        base_tree = commit["tree"]["sha"]
    elif status != 404:
        raise RuntimeError(f"Unexpected ref lookup response {status}: {ref}")

    tree_payload: dict = {"tree": blobs}
    if base_tree:
        tree_payload["base_tree"] = base_tree
    tree = api("POST", f"/repos/{full_name}/git/trees", tree_payload)
    commit = api(
        "POST",
        f"/repos/{full_name}/git/commits",
        {
            "message": "Deploy Amazon Hotbot",
            "tree": tree["sha"],
            "parents": parents,
        },
    )

    if parents:
        api("PATCH", f"/repos/{full_name}/git/refs/heads/{BRANCH}", {"sha": commit["sha"], "force": False})
    else:
        api("POST", f"/repos/{full_name}/git/refs", {"ref": f"refs/heads/{BRANCH}", "sha": commit["sha"]})

    html_url = f"https://github.com/{full_name}"
    print(json.dumps({"repository": full_name, "branch": BRANCH, "commit": commit["sha"], "url": html_url}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
