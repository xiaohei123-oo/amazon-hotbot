from __future__ import annotations

import json
import os
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


TOKEN = os.getenv("VERCEL_TOKEN")
PROJECT = os.getenv("VERCEL_PROJECT_ID", "prj_tJgTzEGvNRwfbNWqSDtt5eUSlEdq")
TEAM_ID = os.getenv("VERCEL_TEAM_ID", "team_bGhGEevf4yM1VjpXDNSbm2tc")
TARGETS = ["production", "preview", "development"]

ENV_KEYS = [
    "FEISHU_WEBHOOK_URL",
    "DATABASE_URL",
    "DRY_RUN",
    "TIMEZONE",
    "DAILY_SEND_TIME",
    "OPENAI_BASE_URL",
    "OPENAI_MODEL",
    "OPENAI_API_KEY",
]


def api_request(method: str, path: str, payload: dict | None = None) -> dict:
    query = urlencode({"teamId": TEAM_ID}) if TEAM_ID else ""
    url = f"https://api.vercel.com{path}" + (f"?{query}" if query else "")
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": "application/json",
        },
        method=method,
    )
    try:
        with urlopen(request, timeout=60) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        if exc.code == 409:
            return {"conflict": True, "detail": detail}
        raise RuntimeError(f"Vercel API error {exc.code}: {detail}") from exc


def main() -> int:
    if not TOKEN:
        print("Missing VERCEL_TOKEN.", file=sys.stderr)
        return 2

    configured: list[str] = []
    skipped: list[str] = []
    for key in ENV_KEYS:
        value = os.getenv(key)
        if value is None or value == "":
            skipped.append(key)
            continue
        result = api_request(
            "POST",
            f"/v10/projects/{PROJECT}/env",
            {
                "key": key,
                "value": value,
                "type": "encrypted" if key.endswith("_KEY") or "WEBHOOK" in key else "plain",
                "target": TARGETS,
            },
        )
        configured.append(f"{key}: {'exists' if result.get('conflict') else 'ok'}")

    print(json.dumps({"configured": configured, "skipped": skipped}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
